// Generated from the original static/styles.css
#pragma once
#include <pgmspace.h>
static const char STYLES_CSS[] PROGMEM = R"CSS(:root {
  color-scheme: light;
  font-family: "Inter", system-ui, sans-serif;
  --bg: #f6f3ed;
  --card: #ffffff;
  --ink: #2b2a28;
  --muted: #6d6a65;
  --accent: #3d6b4f;
  --accent-dark: #2e513c;
  --warning: #f3d69e;
  --danger: #c75d5d;
  --shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  --radius: 18px;
}

body[data-theme="dark"] {
  color-scheme: dark;
  --bg: #1b1c1b;
  --card: #262827;
  --ink: #f0ece6;
  --muted: #b1aca5;
  --accent: #7bb38f;
  --accent-dark: #6da67f;
  --warning: #6d5b30;
  --danger: #d67a7a;
  --shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background: var(--bg);
  color: var(--ink);
}

.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 2rem;
  padding: 2rem 4vw;
  background: #efe8dd;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.site-header h1 {
  margin: 0.2rem 0 0;
  font-size: 1.8rem;
}

.site-header nav {
  display: flex;
  gap: 1.5rem;
  flex-wrap: wrap;
  align-items: center;
}

.site-header a {
  color: var(--ink);
  text-decoration: none;
  font-weight: 600;
}

.button-link {
  background: none;
  border: none;
  padding: 0;
  font: inherit;
  cursor: pointer;
}

.container {
  padding: 2rem 4vw 4rem;
  max-width: 1100px;
  margin: 0 auto;
}

.kicker {
  text-transform: uppercase;
  letter-spacing: 0.2em;
  font-size: 0.7rem;
  margin: 0;
  color: var(--muted);
}

.hero {
  display: flex;
  justify-content: space-between;
  gap: 2rem;
  align-items: center;
  padding: 2rem;
  border-radius: var(--radius);
  background: var(--card);
  box-shadow: var(--shadow);
}

.hero h2 {
  margin-top: 0;
}

.button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.7rem 1.4rem;
  border-radius: 999px;
  border: none;
  background: var(--accent);
  color: white;
  text-decoration: none;
  font-weight: 600;
  cursor: pointer;
}

.button.ghost {
  background: transparent;
  color: var(--accent);
  border: 1px solid var(--accent);
}

.button.danger {
  background: var(--danger);
}

.card-grid {
  margin-top: 2rem;
  display: grid;
  gap: 1.5rem;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
}

.card {
  background: var(--card);
  padding: 1.5rem;
  border-radius: var(--radius);
  box-shadow: var(--shadow);
}

.card h3 {
  margin-top: 0;
}

.card footer {
  margin-top: 1rem;
}

.link {
  color: var(--accent-dark);
  font-weight: 600;
  text-decoration: none;
}

.meta {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
  color: var(--muted);
  font-size: 0.9rem;
}

.empty-state {
  padding: 2rem;
  text-align: center;
  background: var(--card);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
}

.form-card {
  background: var(--card);
  padding: 2rem;
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  margin-bottom: 2rem;
}

.form-card.narrow {
  max-width: 420px;
  margin: 0 auto 2rem;
}

.stack {
  display: grid;
  gap: 1.2rem;
}

label {
  display: grid;
  gap: 0.4rem;
  font-weight: 600;
}

label.inline {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 500;
}

input,
textarea,
select {
  padding: clamp(0.5rem, 1.6vw, 0.75rem) clamp(0.6rem, 2.2vw, 0.9rem);
  border-radius: 12px;
  border: 1px solid #d5d1c9;
  font: inherit;
  font-size: clamp(0.85rem, 3.2vw, 1rem);
  background: #faf8f4;
  width: 100%;
}

select {
  min-height: 120px;
}

body[data-theme="dark"] input,
body[data-theme="dark"] textarea,
body[data-theme="dark"] select {
  border-color: #3a3d3a;
  background: #1f211f;
  color: var(--ink);
}

body[data-theme="dark"] .site-header {
  background: #202221;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

body[data-theme="dark"] .hero,
body[data-theme="dark"] .card,
body[data-theme="dark"] .form-card,
body[data-theme="dark"] .empty-state {
  background: var(--card);
}

body[data-theme="dark"] .attachment {
  background: #1f211f;
}

body[data-theme="dark"] .map-panel {
  border-color: #3a3d3a;
}

body[data-theme="dark"] .tag {
  background: #2c3a32;
  color: #cfe6d8;
}

.theme-toggle {
  font-size: 0.9rem;
}

.helper {
  font-size: 0.8rem;
  color: var(--muted);
  font-weight: 400;
}

.grid-2 {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
}

.flash-stack {
  display: grid;
  gap: 0.6rem;
  margin-bottom: 1rem;
}

.flash {
  padding: 0.8rem 1rem;
  border-radius: 12px;
  background: var(--warning);
}

.flash-success {
  background: #cfe8d2;
}

.detail-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.detail-grid {
  display: grid;
  gap: 1.5rem;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  margin-bottom: 2rem;
}

.preline {
  white-space: pre-wrap;
}

.map {
  width: 100%;
  min-height: 200px;
  border: 0;
  border-radius: 12px;
  margin-top: 0.5rem;
}

.attachments {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
}

.attachment {
  background: #faf8f4;
  padding: 1rem;
  border-radius: 16px;
  display: grid;
  gap: 0.6rem;
}

.attachment img,
model-viewer {
  width: 100%;
  height: 200px;
  border-radius: 12px;
  background: #e2ddd4;
  object-fit: cover;
}

.list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: grid;
  gap: 0.8rem;
}

.list li {
  display: grid;
  gap: 0.3rem;
  background: #faf8f4;
  padding: 0.8rem 1rem;
  border-radius: 12px;
}

.user-card {
  text-align: center;
}

.avatar {
  width: 72px;
  height: 72px;
  border-radius: 50%;
  background: #e9e3d7;
  display: grid;
  place-items: center;
  margin: 0 auto 1rem;
  overflow: hidden;
  font-weight: 700;
  color: var(--accent-dark);
}

.avatar.large {
  width: 110px;
  height: 110px;
  margin: 0;
}

.avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.user-header {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  flex-wrap: wrap;
}

.actions {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
  align-items: center;
}

.actions form {
  margin: 0;
}

.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
  margin-top: 0.4rem;
}

.tag {
  background: #e9efe7;
  color: var(--accent-dark);
  padding: 0.2rem 0.6rem;
  border-radius: 999px;
  font-size: 0.8rem;
  font-weight: 600;
}

.map-panel {
  height: 320px;
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid #d5d1c9;
}

.map-panel.large {
  height: 520px;
}

.search-bar {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
  align-items: center;
  margin-top: 1rem;
}

.search-bar input {
  flex: 1 1 240px;
}

.muted {
  color: var(--muted);
  font-size: 0.9rem;
}

@media (max-width: 720px) {
  .site-header {
    flex-direction: column;
    align-items: flex-start;
  }

  .hero {
    flex-direction: column;
    align-items: flex-start;
  }
}
)CSS";
